import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt


df = pd.read_csv('titanic.csv') 


print("🔹 Dataset Shape:", df.shape)
print("\n🔹 Columns:\n", df.columns)
print("\n🔹 Missing Values:\n", df.isnull().sum())



df['Age'].fillna(df['Age'].median(), inplace=True)


df['Embarked'].fillna(df['Embarked'].mode()[0], inplace=True)

df['Fare'].fillna(df['Fare'].median(), inplace=True)


df['Cabin'].fillna('Unknown', inplace=True)


df['Survived'] = df['Survived'].astype('category')
df['Pclass'] = df['Pclass'].astype('category')
df['Sex'] = df['Sex'].astype('category')
df['Embarked'] = df['Embarked'].astype('category')

print("\n🔹 Data Types After Cleaning:\n", df.dtypes)



sns.set(style="whitegrid")


sns.countplot(data=df, x='Survived')
plt.title("Survival Count")
plt.xlabel("Survived (0 = No, 1 = Yes)")
plt.ylabel("Count")
plt.show()


sns.countplot(data=df, x='Sex', palette='Set2')
plt.title("Gender Distribution")
plt.show()


sns.countplot(data=df, x='Sex', hue='Survived', palette='pastel')
plt.title("Survival by Gender")
plt.show()


sns.countplot(data=df, x='Pclass', hue='Survived', palette='muted')
plt.title("Survival by Passenger Class")
plt.show()

sns.histplot(df['Age'], bins=30, kde=True, color='skyblue')
plt.title("Age Distribution")
plt.xlabel("Age")
plt.show()


sns.boxplot(data=df, x='Survived', y='Age', palette='coolwarm')
plt.title("Age vs Survival")
plt.xticks([0, 1], ['Not Survived', 'Survived'])
plt.show()


sns.countplot(data=df, x='Embarked', hue='Survived', palette='Set3')
plt.title("Survival by Embarkation Port")
plt.show()


sns.countplot(data=df, x='SibSp', hue='Survived', palette='Set1')
plt.title("Survival by Siblings/Spouses Aboard")
plt.show()


sns.countplot(data=df, x='Parch', hue='Survived', palette='Set2')
plt.title("Survival by Parents/Children Aboard")
plt.show()


numeric_df = df[['Survived', 'Age', 'SibSp', 'Parch', 'Fare']]
corr = numeric_df.corr()
sns.heatmap(corr, annot=True, cmap='Blues')
plt.title("Correlation Heatmap")
plt.show()



print("\n🔹 Survival Rate by Gender:\n", df.groupby('Sex')['Survived'].value_counts(normalize=True))
print("\n🔹 Survival Rate by Class:\n", df.groupby('Pclass')['Survived'].value_counts(normalize=True))
print("\n🔹 Mean Age by Survival:\n", df.groupby('Survived')['Age'].mean())


df.to_csv("titanic_cleaned.csv", index=False)
print("✅ All plots saved in 'screenshots' folder and cleaned dataset saved as titanic_cleaned.csv")
